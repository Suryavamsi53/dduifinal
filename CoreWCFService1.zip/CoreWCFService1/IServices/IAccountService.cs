﻿using CoreWCFService1.Models;
using System.ServiceModel;
using CoreWCFService1.DataAccessLayer;
namespace CoreWCFService1.IServices
{
    [CoreWCF.ServiceContract]
    public interface IAccountService
    {
        [CoreWCF.OperationContract]
        Task <Account> GetAccountByIdAsync(int id);

        [CoreWCF.OperationContract]
        Task AddAccountAsync(Account account);

        [CoreWCF.OperationContract]
        Task UpdateAccountAsync(Account account);

        [CoreWCF.OperationContract]
        Task DeleteAccountAsync(int id);
    }
}
